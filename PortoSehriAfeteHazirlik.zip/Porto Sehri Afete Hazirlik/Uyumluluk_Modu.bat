@echo off
rem Oyun cokuyor ya da acilmiyorsa: eski / zayif ekran kartlari icin sade cizim modu (OpenGL)
start "" "%~dp0PortoSehriAfeteHazirlik.exe" --rendering-driver opengl3 --rendering-method gl_compatibility
